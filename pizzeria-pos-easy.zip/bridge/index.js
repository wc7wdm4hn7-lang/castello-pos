import "dotenv/config";
import { printEscpos } from "./escpos_tcp.js";

const API_URL = process.env.API_URL;
const PRINTER_HOST = process.env.PRINTER_HOST;
const PRINTER_PORT = Number(process.env.PRINTER_PORT || 9100);
const POLL_MS = Number(process.env.POLL_MS || 1500);

if (!API_URL || !PRINTER_HOST) {
  console.error("Bitte .env ausfüllen: API_URL und PRINTER_HOST");
  process.exit(1);
}

async function getJSON(path) {
  const r = await fetch(`${API_URL}${path}`);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

async function patchJSON(path, body) {
  const r = await fetch(`${API_URL}${path}`, {
    method: "PATCH",
    headers: { "Content-Type":"application/json" },
    body: JSON.stringify(body)
  });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

console.log("Bridge läuft.");
console.log("Backend:", API_URL);
console.log("Printer:", `${PRINTER_HOST}:${PRINTER_PORT}`);

async function loop() {
  try {
    const job = await getJSON("/api/print/next");
    if (!job) return;

    await patchJSON(`/api/print/${job.id}`, { status: "printing" });

    try {
      await printEscpos({ host: PRINTER_HOST, port: PRINTER_PORT }, job.payload);
      await patchJSON(`/api/print/${job.id}`, { status: "done" });
      console.log("Gedruckt:", job.id);
    } catch (e) {
      await patchJSON(`/api/print/${job.id}`, { status: "error", error: String(e.message || e) });
      console.error("Druckfehler:", e);
    }
  } catch (e) {
    console.error("Bridge Fehler:", e);
  }
}

setInterval(loop, POLL_MS);
