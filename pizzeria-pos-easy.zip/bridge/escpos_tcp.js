import net from "net";

export function printEscpos({ host, port }, text) {
  return new Promise((resolve, reject) => {
    const socket = new net.Socket();

    socket.connect(port, host, () => {
      const ESC = "\x1B";
      const GS = "\x1D";
      const init = Buffer.from(`${ESC}@`, "ascii");
      const body = Buffer.from(text, "utf8");
      const feed = Buffer.from("\n\n", "ascii");
      const cut  = Buffer.from(`${GS}V\x00`, "binary"); // full cut

      socket.write(Buffer.concat([init, body, feed, cut]));
      socket.end();
      resolve(true);
    });

    socket.on("error", (e) => reject(e));
  });
}
