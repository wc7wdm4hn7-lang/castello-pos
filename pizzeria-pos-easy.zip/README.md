# Pizzeria POS (einfach, mehrere Geräte, überall)

**Ziel:** Web-Kasse/Bestellsystem wie im Mockup: Bestellungen + Einstellungen getrennt + Drucker + Live-Sync.  
**Ohne Login** (wie gewünscht).

## Was ist drin?
- Realtime Sync: Socket.IO (alle Geräte sehen sofort Änderungen)
- Postgres Datenbank (Cloud-fähig) via Prisma
- Frontend: Vite + React (läuft auf Handy/Tablet/PC im Browser)
- Bezahlarten: cash / card / online / mixed
- Schnell-Eingabe: Artikelnummer → Gericht + Preis automatisch
- Druck: **Bridge** im Laden (LAN zum Epson TM‑T20III), weil Cloud nicht direkt ins lokale Netzwerk drucken kann

---

## SUPER EINFACH ONLINE (Variante 1 – empfohlen)
Du brauchst nur 3 kostenlose Dienste (kannst du später upgraden):
1) **Supabase** (Postgres DB)
2) **Railway** (Backend/Server)
3) **Vercel** (Frontend)

### A) Datenbank (Supabase)
1. Neues Projekt erstellen
2. In Supabase → **Project Settings → Database → Connection string**
3. Kopiere die **DATABASE_URL** (Postgres URL)

### B) Backend deployen (Railway)
1. Dieses Repo auf GitHub hochladen (als neues Repository)
2. Railway → **New Project → Deploy from GitHub Repo**
3. **Environment Variables** setzen:
   - `DATABASE_URL` = (aus Supabase)
   - `CORS_ORIGIN` = deine Frontend-URL (kommt gleich von Vercel) *oder* erstmal `*`
   - `PORT` = leer lassen (Railway setzt das)
4. In Railway → **Deploy**
5. In Railway → **Settings → Start Command**:
   - `npm run start`
6. In Railway → **Variables** zusätzlich (wichtig für Prisma Migrations):
   - `PRISMA_CLI_BINARY_TARGETS` = `native`

Railway führt automatisch `npm install` aus.  
Nach dem ersten Deploy:
- Öffne Railway Shell/Console und führe aus:
  - `npx prisma migrate deploy`
  - `npm run seed`

### C) Frontend deployen (Vercel)
1. Vercel → **New Project → Import GitHub Repo**
2. Root directory: `client`
3. Environment Variable:
   - `VITE_API_URL` = Railway Backend URL (z.B. `https://...railway.app`)
4. Deploy

Dann zurück zu Railway:
- Setze `CORS_ORIGIN` auf deine Vercel URL (z.B. `https://...vercel.app`)

---

## DRUCKEN IM LADEN (Bridge)
Damit der Bon im Laden rauskommt:

1. Im Laden (Windows PC / Mini-PC / Raspberry Pi) Node.js installieren
2. Ordner `bridge/` auf den PC kopieren
3. `bridge/.env` ausfüllen:
   - `API_URL` = Backend URL (Railway)
   - `PRINTER_HOST` = IP vom Epson (z.B. `192.168.1.50`)
   - `PRINTER_PORT` = meist `9100`
4. Start:
   - `npm install`
   - `npm start`

Wenn du eine Bestellung im Web annimmst → Bridge druckt.

---

## Lokal starten (zum Testen)
### 1) Backend
```bash
cd server
npm install
cp .env.example .env
# DATABASE_URL in .env eintragen (lokales Postgres oder Supabase)
npx prisma migrate dev --name init
npm run seed
npm run dev
```

### 2) Frontend
```bash
cd client
npm install
cp .env.example .env
# VITE_API_URL=http://localhost:4000
npm run dev
```

---

## Screens / Navigation
- **Bestellungen**: Alle / In Verarbeitung / Bereit
- **Einstellungen**: Zeiten, Bezahlarten aktiv
- **Drucker**: Bridge-Modus + Status
