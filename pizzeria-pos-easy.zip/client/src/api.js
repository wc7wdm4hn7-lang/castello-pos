export const API = import.meta.env.VITE_API_URL;

async function req(path, opts) {
  const r = await fetch(`${API}${path}`, opts);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

export const api = {
  get: (p) => req(p),
  post: (p, body) => req(p, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(body) }),
  put: (p, body) => req(p, { method:"PUT", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(body) }),
  patch: (p, body) => req(p, { method:"PATCH", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(body) })
};
