import React, { useEffect, useMemo, useState } from "react";
import { io } from "socket.io-client";
import { api } from "../api.js";

function money(n){ return `${Number(n).toFixed(2).replace(".", ",")} €`; }
function pad4(n){ return String(n).padStart(4,"0"); }

export default function App(){
  const socket = useMemo(()=> io(import.meta.env.VITE_API_URL), []);
  const [tab, setTab] = useState("orders"); // orders | settings | printer
  const [filter, setFilter] = useState("all"); // all | processing | ready

  const [settings, setSettings] = useState(null);
  const [menu, setMenu] = useState([]);
  const [orders, setOrders] = useState([]);

  // new order UI
  const [orderType, setOrderType] = useState("delivery");
  const [cust, setCust] = useState({ name:"", phone:"", address:"" });
  const [payment, setPayment] = useState("cash");
  const [articleInput, setArticleInput] = useState("");
  const [cart, setCart] = useState([]);

  useEffect(()=>{
    socket.on("boot", (data)=>{
      setSettings(data.settings);
      setMenu(data.menu || []);
      setOrders(data.orders || []);
    });
    socket.on("orders:created", (o)=> setOrders(prev => [o, ...prev]));
    socket.on("orders:updated", (o)=> setOrders(prev => prev.map(x => x.id===o.id ? o : x)));
    socket.on("settings:updated", (s)=> setSettings(s));
    socket.on("menu:updated", (item)=> setMenu(prev => {
      const idx = prev.findIndex(x=>x.articleNo===item.articleNo);
      if (idx>=0){ const copy=[...prev]; copy[idx]=item; return copy.sort((a,b)=>a.articleNo-b.articleNo); }
      return [...prev, item].sort((a,b)=>a.articleNo-b.articleNo);
    }));
    return ()=> socket.disconnect();
  }, [socket]);

  useEffect(()=>{
    (async ()=>{
      const [s,m,o] = await Promise.all([api.get("/api/settings"), api.get("/api/menu"), api.get("/api/orders")]);
      setSettings(s); setMenu(m); setOrders(o);
    })().catch(()=>{});
  }, []);

  const paymentsEnabled = settings?.payments || { cash:true, card:true, online:true, mixed:true };

  const visibleOrders = orders.filter(o=>{
    if (filter==="all") return true;
    if (filter==="processing") return o.status==="accepted" || o.status==="processing";
    if (filter==="ready") return o.status==="ready";
    return true;
  });

  function addByArticleNo(no){
    const found = menu.find(m => m.articleNo===no && m.active);
    if(!found) return alert("Artikel nicht gefunden/aktiv.");
    setCart(prev=>{
      const idx = prev.findIndex(x=>x.articleNo===no);
      if (idx>=0){
        const c=[...prev];
        c[idx] = { ...c[idx], qty: c[idx].qty+1 };
        return c;
      }
      return [...prev, { articleNo:no, name:found.name, price:found.price, qty:1 }];
    });
  }

  function cartTotal(){ return cart.reduce((s,i)=>s+i.price*i.qty,0); }

  async function submitOrder(){
    if(cart.length===0) return alert("Keine Artikel.");
    const body = {
      type: orderType,
      name: cust.name || undefined,
      phone: cust.phone || undefined,
      address: cust.address || undefined,
      payment,
      items: cart.map(i=>({ ...i }))
    };
    try{
      await api.post("/api/orders", body);
      setCart([]); setArticleInput("");
      alert("Bestellung gespeichert!");
    }catch(e){
      alert(String(e.message || e));
    }
  }

  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <h2 style={{margin:0}}>Pizzeria Kasse</h2>
      </header>

      {tab==="orders" && (
        <div style={styles.content}>
          <div style={styles.tabsRow}>
            <TabButton active={filter==="all"} onClick={()=>setFilter("all")}>Alle</TabButton>
            <TabButton active={filter==="processing"} onClick={()=>setFilter("processing")}>In Verarbeitung</TabButton>
            <TabButton active={filter==="ready"} onClick={()=>setFilter("ready")}>Bereit</TabButton>
          </div>

          <div style={styles.split}>
            <div style={styles.left}>
              <div style={styles.card}>
                <div style={styles.cardTitle}>Neue Bestellung</div>

                <div style={styles.row}>
                  <label>Typ</label>
                  <select value={orderType} onChange={e=>setOrderType(e.target.value)}>
                    <option value="delivery">Lieferung</option>
                    <option value="pickup">Abholung</option>
                    <option value="dinein">Im Restaurant</option>
                  </select>
                </div>

                <div style={styles.row}>
                  <label>Name</label>
                  <input value={cust.name} onChange={e=>setCust({...cust, name:e.target.value})} placeholder="Name" />
                </div>
                <div style={styles.row}>
                  <label>Telefon</label>
                  <input value={cust.phone} onChange={e=>setCust({...cust, phone:e.target.value})} placeholder="Telefon" />
                </div>
                <div style={styles.row}>
                  <label>Adresse</label>
                  <input value={cust.address} onChange={e=>setCust({...cust, address:e.target.value})} placeholder="Adresse" />
                </div>

                <div style={styles.row}>
                  <label>Zahlung</label>
                  <select value={payment} onChange={e=>setPayment(e.target.value)}>
                    {paymentsEnabled.cash && <option value="cash">Bar</option>}
                    {paymentsEnabled.card && <option value="card">Karte</option>}
                    {paymentsEnabled.online && <option value="online">Online</option>}
                    {paymentsEnabled.mixed && <option value="mixed">Gemischt</option>}
                  </select>
                </div>

                <div style={styles.row}>
                  <label>Artikel-Nr</label>
                  <input
                    value={articleInput}
                    onChange={e=>setArticleInput(e.target.value.replace(/[^0-9]/g,""))}
                    placeholder="z.B. 12"
                    onKeyDown={(e)=>{
                      if(e.key==="Enter" && articleInput){
                        addByArticleNo(parseInt(articleInput,10));
                        setArticleInput("");
                      }
                    }}
                  />
                  <button onClick={()=>{
                    if(!articleInput) return;
                    addByArticleNo(parseInt(articleInput,10));
                    setArticleInput("");
                  }}>+</button>
                </div>

                <div style={{marginTop:10}}>
                  {cart.length===0 ? <div style={{opacity:.7}}>Noch keine Artikel…</div> : (
                    <div style={{display:"grid", gap:6}}>
                      {cart.map((it)=>(
                        <div key={it.articleNo} style={styles.cartLine}>
                          <div><b>{it.articleNo}</b> {it.name}</div>
                          <div style={{display:"flex", gap:8, alignItems:"center"}}>
                            <button onClick={()=>setCart(prev=>prev.map(x=>x.articleNo===it.articleNo ? {...x, qty:Math.max(1,x.qty-1)} : x))}>-</button>
                            <b>{it.qty}</b>
                            <button onClick={()=>setCart(prev=>prev.map(x=>x.articleNo===it.articleNo ? {...x, qty:x.qty+1} : x))}>+</button>
                            <span>{money(it.price*it.qty)}</span>
                            <button onClick={()=>setCart(prev=>prev.filter(x=>x.articleNo!==it.articleNo))}>x</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div style={{display:"flex", justifyContent:"space-between", marginTop:12}}>
                  <b>Summe: {money(cartTotal())}</b>
                  <button onClick={submitOrder} style={styles.primary}>Speichern</button>
                </div>
              </div>
            </div>

            <div style={styles.right}>
              <div style={styles.list}>
                {visibleOrders.map(o=>(
                  <div key={o.id} style={styles.orderCard}>
                    <div style={{display:"flex", justifyContent:"space-between", gap:10}}>
                      <div>
                        <div style={{fontWeight:700}}>#{pad4(o.number)} • {o.type}</div>
                        <div style={{opacity:.8, fontSize:13}}>
                          {o.type==="delivery" ? (o.address || "—") : (o.name || "—")}
                        </div>
                        <div style={{opacity:.7, fontSize:12}}>{new Date(o.createdAt).toLocaleString("de-DE")}</div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontWeight:800}}>{money(o.total)}</div>
                        <div style={{opacity:.75, fontSize:13}}>{o.payment}</div>
                        <StatusPill status={o.status} />
                      </div>
                    </div>

                    <div style={{marginTop:8, opacity:.9}}>
                      {o.items?.map((it)=>(
                        <div key={it.id} style={{display:"flex", justifyContent:"space-between"}}>
                          <span>{it.qty}x {it.name}</span>
                          <span>{money(it.price*it.qty)}</span>
                        </div>
                      ))}
                    </div>

                    <div style={{display:"flex", gap:8, marginTop:10}}>
                      <button onClick={()=>api.patch(`/api/orders/${o.id}/status`, {status:"processing"})}>In Arbeit</button>
                      <button onClick={()=>api.patch(`/api/orders/${o.id}/status`, {status:"ready"})}>Bereit</button>
                      <button onClick={()=>api.patch(`/api/orders/${o.id}/status`, {status:"missed"})}>Verpasst</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {tab==="settings" && settings && (
        <div style={styles.content}>
          <div style={styles.card}>
            <div style={styles.cardTitle}>Einstellungen</div>

            <div style={styles.row}>
              <label>Min Zeit</label>
              <input type="number" value={settings.minTime} onChange={e=>setSettings({...settings, minTime:Number(e.target.value)})} />
            </div>
            <div style={styles.row}>
              <label>Max Zeit</label>
              <input type="number" value={settings.maxTime} onChange={e=>setSettings({...settings, maxTime:Number(e.target.value)})} />
            </div>

            <div style={{marginTop:10, fontWeight:700}}>Bezahlarten aktiv</div>
            {["cash","card","online","mixed"].map(k=>(
              <label key={k} style={{display:"block", marginTop:6}}>
                <input
                  type="checkbox"
                  checked={!!paymentsEnabled[k]}
                  onChange={e=>setSettings({...settings, payments:{...paymentsEnabled, [k]: e.target.checked}})}
                /> {k}
              </label>
            ))}

            <div style={{marginTop:12}}>
              <button
                style={styles.primary}
                onClick={async ()=>{
                  const updated = await api.put("/api/settings", {
                    minTime: settings.minTime,
                    maxTime: settings.maxTime,
                    payments: settings.payments
                  });
                  setSettings(updated);
                  alert("Gespeichert!");
                }}
              >Speichern</button>
            </div>
          </div>
        </div>
      )}

      {tab==="printer" && settings && (
        <div style={styles.content}>
          <div style={styles.card}>
            <div style={styles.cardTitle}>Drucker</div>
            <p style={{opacity:.8, marginTop:6}}>
              Cloud-Mode: Bon läuft über die <b>Bridge</b> im Laden.
            </p>

            <div style={styles.row}>
              <label>Modus</label>
              <select value={settings.printerMode} onChange={e=>setSettings({...settings, printerMode:e.target.value})}>
                <option value="bridge">Bridge (empfohlen)</option>
                <option value="off">Aus</option>
              </select>
            </div>

            <button
              style={styles.primary}
              onClick={async ()=>{
                const updated = await api.put("/api/settings", { printerMode: settings.printerMode });
                setSettings(updated);
                alert("Gespeichert!");
              }}
            >Speichern</button>
          </div>
        </div>
      )}

      <footer style={styles.nav}>
        <NavButton active={tab==="orders"} onClick={()=>setTab("orders")}>Bestellungen</NavButton>
        <NavButton active={tab==="settings"} onClick={()=>setTab("settings")}>Einstellungen</NavButton>
        <NavButton active={tab==="printer"} onClick={()=>setTab("printer")}>Drucker</NavButton>
      </footer>
    </div>
  );
}

function TabButton({active, children, ...props}){
  return <button {...props} style={{...styles.tab, ...(active?styles.tabActive:{})}}>{children}</button>;
}
function NavButton({active, children, ...props}){
  return <button {...props} style={{...styles.navBtn, ...(active?styles.navBtnActive:{})}}>{children}</button>;
}
function StatusPill({status}){
  const map = { accepted:"Akzeptiert", processing:"In Arbeit", ready:"Bereit", missed:"Verpasst" };
  return <div style={styles.pill}>{map[status] || status}</div>;
}

const styles = {
  page: { fontFamily:"system-ui", minHeight:"100vh", display:"flex", flexDirection:"column" },
  header: { padding:12, borderBottom:"1px solid #eee" },
  content: { padding:12, flex:1 },
  tabsRow: { display:"flex", gap:8, marginBottom:12, flexWrap:"wrap" },
  tab: { padding:"10px 12px", borderRadius:999, border:"1px solid #ddd", background:"#fff" },
  tabActive: { borderColor:"#000", fontWeight:700 },
  split: { display:"grid", gridTemplateColumns:"1fr 1.2fr", gap:12 },
  left: {},
  right: {},
  card: { border:"1px solid #ddd", borderRadius:14, padding:12, background:"#fff" },
  cardTitle: { fontWeight:800, marginBottom:8 },
  row: { display:"grid", gridTemplateColumns:"110px 1fr auto", gap:8, alignItems:"center", marginTop:8 },
  cartLine: { display:"flex", justifyContent:"space-between", borderTop:"1px dashed #eee", paddingTop:6 },
  primary: { padding:"10px 12px", borderRadius:10, border:"1px solid #000", background:"#000", color:"#fff" },
  list: { display:"grid", gap:10 },
  orderCard: { border:"1px solid #ddd", borderRadius:14, padding:12, background:"#fff" },
  pill: { display:"inline-block", marginTop:6, padding:"4px 8px", borderRadius:999, border:"1px solid #ddd", fontSize:12, opacity:.85 },
  nav: { position:"sticky", bottom:0, display:"grid", gridTemplateColumns:"1fr 1fr 1fr", borderTop:"1px solid #eee", background:"#fff" },
  navBtn: { padding:"12px 6px", border:"none", background:"transparent" },
  navBtnActive: { fontWeight:800 }
};
