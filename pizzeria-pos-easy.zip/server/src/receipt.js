export function formatReceipt(order) {
  const line = (s = "") => `${s}\n`;
  const money = (n) => `${n.toFixed(2).replace(".", ",")} €`;

  let out = "";
  out += line("PIZZERIA");
  out += line("--------------------------------");
  out += line(`Bestellung: #${String(order.number).padStart(4, "0")}`);
  out += line(`Typ: ${order.type}`);
  if (order.type === "delivery") {
    out += line(`Name: ${order.name ?? ""}`);
    out += line(`Tel:  ${order.phone ?? ""}`);
    out += line(`Adr:  ${order.address ?? ""}`);
  } else if (order.name) {
    out += line(`Name: ${order.name}`);
  }
  out += line("--------------------------------");
  for (const it of order.items) {
    out += line(`${it.qty}x ${it.name}`);
    out += line(`   ${money(it.price * it.qty)}`);
    if (it.note) out += line(`   Note: ${it.note}`);
  }
  out += line("--------------------------------");
  out += line(`Zahlung: ${order.payment}`);
  out += line(`Summe:   ${money(order.total)}`);
  out += line("--------------------------------");
  out += line(new Date(order.createdAt).toLocaleString("de-DE"));
  return out;
}
