import { prisma } from "./prisma.js";

async function main() {
  // settings (id=1) sicherstellen
  await prisma.settings.upsert({
    where: { id: 1 },
    update: {},
    create: { id: 1 }
  });

  // Beispiel-Menü (upsert nach articleNo)
  const menu = [
    { articleNo: 11, name: "Margherita", price: 8.5 },
    { articleNo: 12, name: "Salami", price: 9.5 },
    { articleNo: 13, name: "Tonno", price: 10.5 },
    { articleNo: 21, name: "Cola 0,33", price: 2.5 },
    { articleNo: 22, name: "Wasser 0,5", price: 2.0 }
  ];

  for (const m of menu) {
    await prisma.menu.upsert({
      where: { articleNo: m.articleNo },
      update: { name: m.name, price: m.price, active: true },
      create: { articleNo: m.articleNo, name: m.name, price: m.price, active: true }
    });
  }

  console.log("Seed fertig.");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
