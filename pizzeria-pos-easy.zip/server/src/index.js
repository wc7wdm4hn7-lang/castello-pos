import express from "express";
import cors from "cors";
import { createServer } from "http";
import { Server as IO } from "socket.io";
import { z } from "zod";
import { prisma } from "./prisma.js";
import { formatReceipt } from "./receipt.js";

const app = express();
app.use(express.json());

const corsOrigin = process.env.CORS_ORIGIN || "*";
app.use(cors({ origin: corsOrigin === "*" ? true : corsOrigin }));

const httpServer = createServer(app);
const io = new IO(httpServer, { cors: { origin: corsOrigin === "*" ? "*" : corsOrigin } });

function emit(event, payload) {
  io.emit(event, payload);
}

function calcTotal(items) {
  return items.reduce((s, i) => s + i.price * i.qty, 0);
}

async function nextOrderNumber() {
  const last = await prisma.order.findFirst({ orderBy: { createdAt: "desc" } });
  return (last?.number ?? 0) + 1;
}

// ---------- SETTINGS ----------
app.get("/api/settings", async (_, res) => {
  const s = await prisma.settings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
  res.json(s);
});

app.put("/api/settings", async (req, res) => {
  const schema = z.object({
    minTime: z.number().int().min(1).max(999).optional(),
    maxTime: z.number().int().min(1).max(999).optional(),
    printerMode: z.enum(["bridge", "off"]).optional(),
    payments: z.record(z.boolean()).optional()
  });

  const data = schema.parse(req.body);
  const updated = await prisma.settings.upsert({
    where: { id: 1 },
    update: data,
    create: { id: 1, ...data }
  });

  emit("settings:updated", updated);
  res.json(updated);
});

// ---------- MENU ----------
app.get("/api/menu", async (_, res) => {
  const menu = await prisma.menu.findMany({ orderBy: { articleNo: "asc" } });
  res.json(menu);
});

app.post("/api/menu", async (req, res) => {
  const schema = z.object({
    articleNo: z.number().int(),
    name: z.string().min(1),
    price: z.number().min(0),
    active: z.boolean().optional()
  });
  const p = schema.parse(req.body);

  const item = await prisma.menu.upsert({
    where: { articleNo: p.articleNo },
    update: { name: p.name, price: p.price, active: p.active ?? true },
    create: { articleNo: p.articleNo, name: p.name, price: p.price, active: p.active ?? true }
  });

  emit("menu:updated", item);
  res.json(item);
});

// ---------- ORDERS ----------
app.get("/api/orders", async (req, res) => {
  const status = req.query.status?.toString();
  const where = status ? { status } : {};
  const orders = await prisma.order.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { items: true }
  });
  res.json(orders);
});

app.post("/api/orders", async (req, res) => {
  const schema = z.object({
    type: z.enum(["delivery", "pickup", "dinein"]),
    name: z.string().optional(),
    phone: z.string().optional(),
    address: z.string().optional(),
    payment: z.enum(["cash", "card", "online", "mixed"]),
    items: z.array(z.object({
      articleNo: z.number().int(),
      name: z.string(),
      price: z.number(),
      qty: z.number().int().min(1),
      note: z.string().optional()
    })).min(1)
  });

  const data = schema.parse(req.body);

  // Pflichtfelder Lieferung
  if (data.type === "delivery") {
    if (!data.name || !data.phone || !data.address) {
      return res.status(400).json({ error: "Bei Lieferung sind Name, Telefon und Adresse Pflicht." });
    }
  }

  const number = await nextOrderNumber();
  const total = calcTotal(data.items);

  const order = await prisma.order.create({
    data: {
      number,
      type: data.type,
      name: data.name,
      phone: data.phone,
      address: data.address,
      status: "accepted",
      payment: data.payment,
      total,
      items: { create: data.items }
    },
    include: { items: true }
  });

  emit("orders:created", order);

  // PrintJob erzeugen (Bridge druckt)
  const settings = await prisma.settings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
  if (settings.printerMode === "bridge") {
    const payload = formatReceipt(order);
    const job = await prisma.printJob.create({
      data: { orderId: order.id, payload }
    });
    emit("print:queued", job);
  }

  res.json(order);
});

app.patch("/api/orders/:id/status", async (req, res) => {
  const schema = z.object({ status: z.enum(["accepted", "processing", "ready", "missed"]) });
  const { status } = schema.parse(req.body);

  const order = await prisma.order.update({
    where: { id: req.params.id },
    data: { status },
    include: { items: true }
  });

  emit("orders:updated", order);
  res.json(order);
});

// ---------- PRINT QUEUE (für Bridge) ----------
app.get("/api/print/next", async (req, res) => {
  // optionaler "token" könnte später ergänzt werden – aktuell absichtlich einfach
  const job = await prisma.printJob.findFirst({
    where: { status: "queued" },
    orderBy: { createdAt: "asc" }
  });
  res.json(job ?? null);
});

app.patch("/api/print/:id", async (req, res) => {
  const schema = z.object({
    status: z.enum(["printing", "done", "error"]),
    error: z.string().optional()
  });
  const data = schema.parse(req.body);

  const job = await prisma.printJob.update({
    where: { id: req.params.id },
    data: {
      status: data.status,
      error: data.error,
      doneAt: data.status === "done" ? new Date() : undefined
    }
  });

  emit("print:updated", job);
  res.json(job);
});

// ---------- SOCKET BOOT ----------
io.on("connection", async (socket) => {
  const [settings, menu, orders] = await Promise.all([
    prisma.settings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } }),
    prisma.menu.findMany({ orderBy: { articleNo: "asc" } }),
    prisma.order.findMany({ orderBy: { createdAt: "desc" }, include: { items: true }, take: 50 })
  ]);

  socket.emit("boot", { settings, menu, orders });
});

const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, () => console.log(`Server läuft auf :${PORT}`));
